package Unit11.Assignments;
//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class - 
//Lab  -

public class WordPrinter
{
	//instance variables and constructors could be present, but are not necessary
		
	public static void printWord(String word, int times)
	{
		for(int i = 0; i < times; i++) {
			System.out.println(word);
		}
	}
}