package Unit7.Assignments;


//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class - 
//Lab  -

public class Lab11c
{
   public static void main( String args[] )
   {
		for(int i = 0; i < 10; i++) {
			System.out.println(new TriangleThree(i, "" + i));
		}
	}
}