package Unit0.Assignments;
//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

public class Lab0b
{
	public static void main ( String[] args )
	{
		//define 1 variable of each of the
		//following data types
		//byte		short		int 		long
		//float		double
		//char      boolean		String

		//integer variables
		byte theByte = 127;
		short theShort = 0x1234;
		int theInt = 500000000;
		long theLong = 0xFFFFFFFF+2140000000;

		//decimal variables
		float theFloat = 500000/123;
		double theDouble = 0xABCDEF/0x123456;

		//other integer types

		//other types
		char theChar = '}';
		boolean theBoolean = false;
		String theString = "qwertyuiop";

		//output your information here
		System.out.println("/////////////////////////////////");
		System.out.println("*Alex Chen                2/1/17*");
		System.out.println("*                               *");
		System.out.println("*        integer types          *");
		System.out.println("*                               *");
		System.out.println("*8 bit - theByte = "+theByte+"\t\t*");
		System.out.println("*16 bit - theShort = "+theShort+"\t*");
		System.out.println("*32 bit - theInt = "+theInt+"\t*");
		System.out.println("*64 bit - theLong = "+theLong+"\t*");
		System.out.println("*                               *");
		System.out.println("*        decimal types          *");
		System.out.println("*                               *");
		System.out.println("*32 bit - theFloat = "+theFloat+"\t*");
		System.out.println("*64 bit - theDouble = "+theDouble+"\t*");
		System.out.println("*                               *");
		System.out.println("*        other integer types    *");
		System.out.println("*                               *");
		System.out.println("*          ??????????           *");
		System.out.println("*                               *");
		System.out.println("*        other types            *");
		System.out.println("*theChar = "+theChar+"\t\t\t*");
		System.out.println("*theBoolean = "+theBoolean+"\t\t*");
		System.out.println("*theString = "+theString+"\t\t*");
		System.out.println("/////////////////////////////////");
	}
}