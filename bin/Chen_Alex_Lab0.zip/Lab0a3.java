package Unit0.Assignments;

//� A+ Computer Science  -  www.apluscompsci.com
//Name - Alex Chen
//Date - 2/1/17
//Class - AP Computer Science A
//Lab  -

public class Lab0a3
{
	public static void main ( String[] args )
	{
		//Look at this ASCII Bat
		System.out.println("Alex Chen");
		System.out.println("2/1/17");
		System.out.println("Period 2");
		System.out.println("                                          __  ");
		System.out.println("                                    ____--  > ");
		System.out.println("                                   /       /  ");
		System.out.println("                                 /____    /   ");
		System.out.println("                                /\\    --->   ");
		System.out.println("            ___---^\\   _   _   |   \\    /   ");
		System.out.println("          --    / | \\ / \\_/ \\_/      \\ /    ");
		System.out.println("         /    /   |  \\| ..  |       __V      ");
		System.out.println("       /    /     |   \\     /\\     /        ");
		System.out.println("      /    |  __  |    \\___/  \\  /          ");
		System.out.println("      |_---V--  --\\/--__|      \\>           ");
		System.out.println("                        V_     /              ");
		System.out.println("                          \\__/               ");
		System.out.println("  __   __    __   ___          __    __    _   ___");
		System.out.println(" /    /  \\  |  \\   |   |\\  |  /     |  \\  / \\   | ");
		System.out.println(" |   |    | |  |   |   | \\ | |  __  |  < |___|  | ");
		System.out.println(" \\__  \\__/  |__/  _|_  |  \\|  \\__|  |__/ |   |  | ");
	}
}