package Unit10.Assignments.Lab16d;


//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;

public class Lab16d
{
	public static void main( String args[] )
	{
		//make a new MadLib
		System.out.println(new MadLib());
	}
}