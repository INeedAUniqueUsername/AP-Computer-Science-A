package Unit6.Assignments;


//� A+ Computer Science  -  www.apluscompsci.com
//Name -
//Date -
//Class -
//Lab  -

import static java.lang.System.*;
import java.lang.Math;

public class Lab08i
{
	public static void main ( String[] args )
	{
		//add test cases
		for(int i = 1; i <= 30; i += 3) {
			System.out.println(new Prime(i));
		}
	}	
}