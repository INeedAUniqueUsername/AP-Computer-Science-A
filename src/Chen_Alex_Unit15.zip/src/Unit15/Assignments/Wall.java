package Unit15.Assignments;

import java.awt.Color;

public class Wall extends Block {
	public Wall(int x, int y, int w, int h) {
		super(x, y, w, h, new Color(0));
	}
}
